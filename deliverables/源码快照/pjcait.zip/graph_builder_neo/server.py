from datetime import datetime
from flask import Flask, request
import logging
from concurrent.futures import ThreadPoolExecutor
import requests

app = Flask(__name__)

from neo4j import GraphDatabase

import builder2

driver = GraphDatabase.driver("bolt://127.0.0.1:7687", auth=('neo4j', 'Test2333!'), database='kh-trade-news-graph')

@app.route('/api', methods=['POST'])
def add_data():
    req_json = request.get_json()
    content = req_json.get('content')

    pass